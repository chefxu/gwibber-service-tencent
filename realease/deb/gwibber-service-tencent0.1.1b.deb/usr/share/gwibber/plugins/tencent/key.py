def get_tencent_keys():
  # Distros should register their own keys and not rely on the defaults
  return "c243bff1f68048ab9030f2cd3044ec1e", "fd1b5ab465f35e5fb7dfc27457e02a47"

